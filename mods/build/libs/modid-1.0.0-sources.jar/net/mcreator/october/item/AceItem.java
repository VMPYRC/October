
package net.mcreator.october.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.lang.reflect.Type;

public abstract class AceItem extends class_1738 {
	public AceItem(class_8051 type, class_1792.class_1793 properties) {
		super(new class_1741() {
			@Override
			public int method_48402(class_8051 type) {
				return new int[]{13, 15, 16, 11}[type.method_48399().method_5927()] * 100;
			}

			@Override
			public int method_48403(class_8051 type) {
				return new int[]{100, 100, 100, 100}[type.method_48399().method_5927()];
			}

			@Override
			public int method_7699() {
				return 50;
			}

			@Override
			public class_3414 method_7698() {
				return class_7923.field_41172.method_10223(new class_2960("item.armor.equip_iron"));
			}

			@Override
			public class_1856 method_7695() {
				return class_1856.method_35226();
			}

			@Environment(EnvType.CLIENT)
			@Override
			public String method_7694() {
				return "ace_";
			}

			@Override
			public float method_7700() {
				return 10f;
			}

			@Override
			public float method_24355() {
				return 5f;
			}
		}, type, properties);
	}

	public static class Helmet extends AceItem {
		public Helmet() {
			super(class_8051.field_41934, new class_1792.class_1793().method_24359());
			ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(content -> content.method_45421(this));
		}

	}

	public static class Chestplate extends AceItem {

		public Chestplate() {
			super(class_8051.field_41935, new class_1792.class_1793().method_24359());
			ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(content -> content.method_45421(this));
		}

	}

	public static class Leggings extends AceItem {

		public Leggings() {
			super(class_8051.field_41936, new class_1792.class_1793().method_24359());
			ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(content -> content.method_45421(this));
		}

	}

	public static class Boots extends AceItem {

		public Boots() {
			super(class_8051.field_41937, new class_1792.class_1793().method_24359());
			ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(content -> content.method_45421(this));
		}

	}
}
