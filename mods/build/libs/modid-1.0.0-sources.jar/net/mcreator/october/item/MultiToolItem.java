
package net.mcreator.october.item;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_5134;
import net.minecraft.class_7706;
import com.google.common.collect.Multimap;
import com.google.common.collect.ImmutableMultimap;

public class MultiToolItem extends class_1831 {
	public MultiToolItem() {
		super(new class_1832() {
			public int method_8025() {
				return 10000;
			}

			public float method_8027() {
				return 50f;
			}

			public float method_8028() {
				return 998f;
			}

			public int method_8024() {
				return 5;
			}

			public int method_8026() {
				return 50;
			}

			public class_1856 method_8023() {
				return class_1856.method_35226();
			}
		}, new class_1792.class_1793().method_24359());
		ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> content.method_45421(this));
	}

	@Override
	public boolean method_7856(class_2680 blockstate) {
		int tier = 5;
		if (tier < 3 && blockstate.method_26164(class_3481.field_33717)) {
			return false;
		} else if (tier < 2 && blockstate.method_26164(class_3481.field_33718)) {
			return false;
		} else {
			return tier < 1 && blockstate.method_26164(class_3481.field_33719)
					? false
					: (blockstate.method_26164(class_3481.field_33713) || blockstate.method_26164(class_3481.field_33714) || blockstate.method_26164(class_3481.field_33715) || blockstate.method_26164(class_3481.field_33716));
		}
	}

	@Override
	public float method_7865(class_1799 itemstack, class_2680 blockstate) {
		return 50f;
	}

	@Override
	public Multimap<class_1320, class_1322> method_7844(class_1304 equipmentSlot) {
		if (equipmentSlot == class_1304.field_6173) {
			ImmutableMultimap.Builder<class_1320, class_1322> builder = ImmutableMultimap.builder();
			builder.putAll(super.method_7844(equipmentSlot));
			builder.put(class_5134.field_23721, new class_1322(field_8006, "Tool modifier", 998f, class_1322.class_1323.field_6328));
			builder.put(class_5134.field_23723, new class_1322(field_8001, "Tool modifier", 46, class_1322.class_1323.field_6328));
			return builder.build();
		}
		return super.method_7844(equipmentSlot);
	}

	@Override
	public boolean method_7873(class_1799 stack, class_1309 entity, class_1309 sourceentity) {
		stack.method_7956(2, sourceentity, i -> i.method_20235(class_1304.field_6173));
		return true;
	}

	@Override
	public boolean method_7879(class_1799 stack, class_1937 world, class_2680 state, class_2338 pos, class_1309 entity) {
		stack.method_7956(1, entity, i -> i.method_20235(class_1304.field_6173));
		return true;
	}
}
