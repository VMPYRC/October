
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.october.init;

import net.mcreator.october.OctoberMod;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1842;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class OctoberModPotions {
	public static class_1842 GOD;

	public static void load() {
		GOD = class_2378.method_10230(class_7923.field_41179, new class_2960(OctoberMod.MODID, "god"),
				new class_1842(new class_1293(class_1294.field_5918, 1316134912, 255, false, false), new class_1293(class_1294.field_18980, 1316134912, 255, false, false),
						new class_1293(class_1294.field_5915, 1316134912, 255, false, false), new class_1293(class_1294.field_5926, 1316134912, 255, false, false), new class_1293(class_1294.field_5924, 1316134912, 255, false, false),
						new class_1293(class_1294.field_5907, 1316134912, 255, false, false), new class_1293(class_1294.field_5922, 1316134912, 255, false, false),
						new class_1293(class_1294.field_5910, 1316134912, 255, false, false), new class_1293(class_1294.field_5923, 1316134912, 255, false, false)));
	}
}
