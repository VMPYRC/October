/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.october.init;

import net.mcreator.october.item.WandItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.mcreator.october.item.AceItem;
import net.mcreator.october.OctoberMod;

public class OctoberModItems {
	public static class_1792 ACE_HELMET;
	public static class_1792 ACE_CHESTPLATE;
	public static class_1792 ACE_LEGGINGS;
	public static class_1792 ACE_BOOTS;
	public static class_1792 WAND;

	public static void load() {
		ACE_HELMET = class_2378.method_10230(class_7923.field_41178, new class_2960(OctoberMod.MODID, "ace_helmet"), new AceItem.Helmet());
		ACE_CHESTPLATE = class_2378.method_10230(class_7923.field_41178, new class_2960(OctoberMod.MODID, "ace_chestplate"), new AceItem.Chestplate());
		ACE_LEGGINGS = class_2378.method_10230(class_7923.field_41178, new class_2960(OctoberMod.MODID, "ace_leggings"), new AceItem.Leggings());
		ACE_BOOTS = class_2378.method_10230(class_7923.field_41178, new class_2960(OctoberMod.MODID, "ace_boots"), new AceItem.Boots());
		WAND = class_2378.method_10230(class_7923.field_41178, new class_2960(OctoberMod.MODID, "wand"), new WandItem());
	}

	public static void clientLoad() {
	}
}
